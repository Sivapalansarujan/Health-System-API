/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.dao;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.model.Billing;
import com.mycompany.healthsystemcoursework.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class BillingDAO {
    private static List<Billing> billings = new ArrayList<>();

    static {
        // Initialize some sample billings
        Patient patient1 = new Patient(1, "Browns", "Browns@example.com", "3 browns St", "Stress", "Recovering");
        billings.add(new Billing(1, patient1, 1000.00, false));

        Patient patient2 = new Patient(2, "Micheal", "Micheal@example.com", "4 micheal St", "Food allergy", "Stable");
        billings.add(new Billing(2, patient2, 2000.00, true));
        // Add more billings as needed
    }

    public List<Billing> getAllBillings() {
        return billings;
    }

    public Billing getBillingById(int id) {
        for (Billing billing : billings) {
            if (billing.getId() == id) {
                return billing;
            }
        }
        return null;
    }

    public void addBilling(Billing billing) {
        billings.add(billing);
    }

    public void updateBilling(Billing updatedBilling) {
        for (int i = 0; i < billings.size(); i++) {
            Billing billing = billings.get(i);
            if (billing.getId() == updatedBilling.getId()) {
                billings.set(i, updatedBilling);
                return;
            }
        }
    }

    public void deleteBilling(int id) {
        billings.removeIf(billing -> billing.getId() == id);
    }
}

