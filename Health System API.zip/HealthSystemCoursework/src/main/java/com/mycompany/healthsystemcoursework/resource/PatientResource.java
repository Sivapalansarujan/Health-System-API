/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.resource;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.dao.PatientDAO;
import com.mycompany.healthsystemcoursework.model.Patient;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/patients")
public class PatientResource {
    private PatientDAO patientDAO = new PatientDAO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Patient> getAllPatients() {
        return patientDAO.getAllPatients();
    }

    @GET
    @Path("/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Patient getPatientById(@PathParam("patientId") int patientId) {
        return patientDAO.getPatientById(patientId);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addPatient(Patient patient) {
        patientDAO.addPatient(patient);
    }

    @PUT
    @Path("/{patientId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updatePatient(@PathParam("patientId") int patientId, Patient updatedPatient) {
        Patient existingPatient = patientDAO.getPatientById(patientId);

        if (existingPatient != null) {
            updatedPatient.setId(patientId);
            patientDAO.updatePatient(updatedPatient);
        }
    }

    @DELETE
    @Path("/{patientId}")
    public void deletePatient(@PathParam("patientId") int patientId) {
        patientDAO.deletePatient(patientId);
    }
}

