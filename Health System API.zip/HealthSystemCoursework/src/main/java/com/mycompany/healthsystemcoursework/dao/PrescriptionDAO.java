/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.dao;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.model.Patient;
import com.mycompany.healthsystemcoursework.model.Prescription;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionDAO {
    private static List<Prescription> prescriptions = new ArrayList<>();

    static {
        // Initialize some sample prescriptions
        Patient patient1 = new Patient(1, "Browns", "Browns@example.com", "3 browns St", "Stress", "Recovering");
        prescriptions.add(new Prescription(1, patient1, "Tablet01", "100 mg", "Take one tablet daily before sleep", "1 month"));

        Patient patient2 = new Patient(2, "Micheal", "Micheal@example.com", "4 micheal St", "Food allergy", "Stable");
        prescriptions.add(new Prescription(2, patient2, "Tablet02", "200 mg", "Take one tablet daily with food", "2 weeks"));
        // Add more prescriptions as needed
    }
    
    public List<Prescription> getAllPrescriptions() {
        return prescriptions;
    }

    public Prescription getPrescriptionById(int id) {
        for (Prescription prescription : prescriptions) {
            if (prescription.getId() == id) {
                return prescription;
            }
        }
        return null;
    }

    public void addPrescription(Prescription prescription) {
        prescriptions.add(prescription);
    }

    public void updatePrescription(Prescription updatedPrescription) {
        for (int i = 0; i < prescriptions.size(); i++) {
            Prescription prescription = prescriptions.get(i);
            if (prescription.getId() == updatedPrescription.getId()) {
                prescriptions.set(i, updatedPrescription);
                return;
            }
        }
    }

    public void deletePrescription(int id) {
        prescriptions.removeIf(prescription -> prescription.getId() == id);
    }
}

