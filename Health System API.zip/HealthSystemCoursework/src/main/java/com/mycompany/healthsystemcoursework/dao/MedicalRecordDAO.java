/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.dao;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.model.MedicalRecord;
import com.mycompany.healthsystemcoursework.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {
    private static List<MedicalRecord> medicalRecords = new ArrayList<>();

    static {
        // Initialize some sample medical records
        Patient patient1 = new Patient(1,  "Browns", "Browns@example.com", "3 browns St", "Stress", "Recovering");
        medicalRecords.add(new MedicalRecord(1, patient1, "Headache", "Meditation and medication"));

        Patient patient2 = new Patient(2, "Micheal", "Micheal@example.com", "4 micheal St", "Food allergy", "Stable");
        medicalRecords.add(new MedicalRecord(2, patient2, "Vomiting", "Medication"));
        // Add more medical records as needed
    }
        
    public List<MedicalRecord> getAllMedicalRecords() {
        return medicalRecords;
    }

    public MedicalRecord getMedicalRecordById(int id) {
        for (MedicalRecord medicalRecord : medicalRecords) {
            if (medicalRecord.getId() == id) {
                return medicalRecord;
            }
        }
        return null;
    }

    public void addMedicalRecord(MedicalRecord medicalRecord) {
        medicalRecords.add(medicalRecord);
    }

    public void updateMedicalRecord(MedicalRecord updatedMedicalRecord) {
        for (int i = 0; i < medicalRecords.size(); i++) {
            MedicalRecord medicalRecord = medicalRecords.get(i);
            if (medicalRecord.getId() == updatedMedicalRecord.getId()) {
                medicalRecords.set(i, updatedMedicalRecord);
                return;
            }
        }
    }

    public void deleteMedicalRecord(int id) {
        medicalRecords.removeIf(medicalRecord -> medicalRecord.getId() == id);
    }
}


