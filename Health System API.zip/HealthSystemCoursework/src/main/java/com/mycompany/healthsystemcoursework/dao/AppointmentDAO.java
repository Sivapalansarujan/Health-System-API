/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.dao;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.model.Appointment;
import com.mycompany.healthsystemcoursework.model.Doctor;
import com.mycompany.healthsystemcoursework.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    private static List<Appointment> appointments = new ArrayList<>();

    static {
        Doctor doctor1 = new Doctor(1, "Dr.John", "John@example.com", "1 john St", "Neurologist");
        Patient patient1 = new Patient(1, "Browns", "Browns@example.com", "3 browns St", "Stress", "Recovering");
        appointments.add(new Appointment(1, "2024-07-07", "07:00", patient1, doctor1));

        Doctor doctor2 = new Doctor(2, "Dr.Smith", "Smith@example.com", "2 smith St", "Psychiatrist");
        Patient patient2 = new Patient(2, "Micheal", "Micheal@example.com", "4 micheal St", "Food allergy", "Stable");
        appointments.add(new Appointment(2, "2024-08-08", "08:00", patient2, doctor2));
    }

    public List<Appointment> getAllAppointments() {
        return appointments;
    }

    public Appointment getAppointmentById(int id) {
        for (Appointment appointment : appointments) {
            if (appointment.getId() == id) {
                return appointment;
            }
        }
        return null;
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public void updateAppointment(Appointment updatedAppointment) {
        for (int i = 0; i < appointments.size(); i++) {
            Appointment appointment = appointments.get(i);
            if (appointment.getId() == updatedAppointment.getId()) {
                appointments.set(i, updatedAppointment);
                return;
            }
        }
    }

    public void deleteAppointment(int id) {
        appointments.removeIf(appointment -> appointment.getId() == id);
    }
}
