/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.model;

/**
 *
 * @author Sarujan
 */

public class Billing {
    private int id;
    private Patient patient;
    private double amount;
    private boolean paid;

    public Billing(int id, Patient patient, double amount, boolean paid) {
        this.id = id;
        this.patient = patient;
        this.amount = amount;
        this.paid = paid;
    }

    // Getter for id
    public int getId() {
        return id;
    }

    // Setter for id
    public void setId(int id) {
        this.id = id;
    }

    // Getter for patient
    public Patient getPatient() {
        return patient;
    }

    // Setter for patient
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    // Getter for amount
    public double getAmount() {
        return amount;
    }

    // Setter for amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Getter for paid
    public boolean isPaid() {
        return paid;
    }

    // Setter for paid
    public void setPaid(boolean paid) {
        this.paid = paid;
    }
}

