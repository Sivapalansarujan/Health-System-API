/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystemcoursework.dao;

/**
 *
 * @author Sarujan
 */

import com.mycompany.healthsystemcoursework.model.Person;
import java.util.ArrayList;
import java.util.List;

public class PersonDAO {
    private static List<Person> persons = new ArrayList<>();

    static {
        persons.add(new Person(1, "Dr.John", "John@example.com", "1 john St"));
        persons.add(new Person(2, "Dr.Smith", "Smith@example.com", "2 smith St"));
        persons.add(new Person(3, "Browns", "Browns@example.com", "3 browns St"));
        persons.add(new Person(4, "Micheal", "Micheal@example.com", "4 micheal St"));
    }

    public List<Person> getAllPersons() {
        return persons;
    }

    public Person getPersonById(int id) {
        for (Person person : persons) {
            if (person.getId() == id) {
                return person;
            }
        }
        return null;
    }

    public void addPerson(Person person) {
        persons.add(person);
    }

    public void updatePerson(Person updatedPerson) {
        for (int i = 0; i < persons.size(); i++) {
            Person person = persons.get(i);
            if (person.getId() == updatedPerson.getId()) {
                persons.set(i, updatedPerson);
                return;
            }
        }
    }

    public void deletePerson(int id) {
        persons.removeIf(person -> person.getId() == id);
    }
}

